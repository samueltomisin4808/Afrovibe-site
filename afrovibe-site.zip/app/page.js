export default function Home() {
  return (
    <main style={{background: 'black', color: 'white', minHeight: '100vh', padding: '40px'}}>
      <h1>AfroVibe Events</h1>
      <h2>REWIND: Y2K EXPERIENCE</h2>
      <p>June 26 • 10PM • The Dome</p>
      <a href="https://buy.stripe.com/test_link" target="_blank">
        <button style={{padding: '10px 20px', marginTop: '20px'}}>Get Tickets</button>
      </a>
    </main>
  );
}